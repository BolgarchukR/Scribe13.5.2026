# hotkey_manager.py
import logging
import platform

from pynput import keyboard
from PyQt5.QtCore import QObject

logger = logging.getLogger(__name__)

class HotkeyManager(QObject):
    """Manages global hotkeys for the application using pynput."""

    def __init__(self, settings_manager, controller):
        super().__init__()
        self.settings_manager = settings_manager
        self.controller = controller
        self.listener = None
        self._last_registered_hotkeys = {}
        self.register_hotkeys()
        self.settings_manager.settings_changed.connect(self.on_settings_changed)

    def on_settings_changed(self, new_settings):
        """Re-registers hotkeys if they have changed in the settings."""
        new_modes = new_settings.get('modes', self.settings_manager.DEFAULTS['modes'])
        new_models_hotkeys = new_settings.get('models_hotkeys', self.settings_manager.DEFAULTS['models_hotkeys'])

        last_modes = self._last_registered_hotkeys.get('modes', {})
        last_models_hotkeys = self._last_registered_hotkeys.get('models_hotkeys', {})

        if new_modes != last_modes or new_models_hotkeys != last_models_hotkeys:
            logger.info("Hotkey settings changed, re-registering...")
            self.register_hotkeys()

    def _to_pynput_format(self, key_str: str):
        """Converts a hotkey string like 'Ctrl+Shift+Q' to pynput format '<ctrl>+<shift>+q'.
        
        pynput format examples:
        - Ctrl+Shift+Q → '<ctrl>+<shift>+q'
        - Ctrl+Alt+Q → '<ctrl>+<alt>+q'
        """
        if not key_str:
            return None

        keys = key_str.lower().split('+')
        formatted_keys = []

        key_map = {
            'ctrl': 'ctrl',
            'alt': 'alt',
            'shift': 'shift',
            'cmd': 'cmd',
            'win': 'cmd',
            'super': 'cmd'
        }

        for key in keys:
            key = key.strip()
            if key in key_map:
                formatted_keys.append(f"<{key_map[key]}>")
            elif len(key) == 1:
                # Single character key - keep as is
                formatted_keys.append(key)
            else:
                # Named key like 'home', 'end', 'pageup', etc.
                formatted_keys.append(key)

        result = "+".join(formatted_keys)
        logger.debug(f"[Hotkey Format] '{key_str}' → '{result}'")
        return result

    def register_hotkeys(self):
        """Stops the old listener and registers new hotkeys from settings with robust error handling."""
        self.stop()

        hotkey_map = {}

        # Mode hotkeys
        modes = self.settings_manager.get('modes', {})
        transcribe_hotkey = modes.get('transcribe_mode', 'Ctrl+Shift+Q')
        command_hotkey = modes.get('command_mode', 'Ctrl+Alt+Q')

        logger.info(f"[HotkeyManager] Attempting to register hotkeys:")
        logger.info(f"  Transcribe: {transcribe_hotkey}")
        logger.info(f"  Command: {command_hotkey}")

        pynput_transcribe = self._to_pynput_format(transcribe_hotkey)
        if pynput_transcribe:
            # Bind directly without wrapper functions - simpler and more reliable
            hotkey_map[pynput_transcribe] = self._make_safe_callback(
                self.controller.switch_to_transcribe_mode, 
                f"Transcribe mode ({transcribe_hotkey})"
            )
            logger.info(f"[HotkeyManager] Registered: {transcribe_hotkey} (pynput: {pynput_transcribe})")

        pynput_command = self._to_pynput_format(command_hotkey)
        if pynput_command:
            # Bind directly without wrapper functions
            hotkey_map[pynput_command] = self._make_safe_callback(
                self.controller.switch_to_command_mode,
                f"Command mode ({command_hotkey})"
            )
            logger.info(f"[HotkeyManager] Registered: {command_hotkey} (pynput: {pynput_command})")

        # Model switching hotkeys
        models_dict = self.settings_manager.get('models', {})
        models_hotkeys = self.settings_manager.get('models_hotkeys', {})
        model_names = set()
        for lang_models in models_dict.values():
            for model in lang_models:
                name = model.get('name')
                if name:
                    model_names.add(name)

        for model_name in model_names:
            hotkey = models_hotkeys.get(model_name, '')
            if hotkey:
                pynput_hotkey = self._to_pynput_format(hotkey)
                if pynput_hotkey:
                    hotkey_map[pynput_hotkey] = self._make_safe_callback(
                        lambda m=model_name: self._switch_model(m),
                        f"Switch to {model_name} ({hotkey})"
                    )
                    logger.info(f"[HotkeyManager] Registered: {hotkey} (pynput: {pynput_hotkey}) → {model_name}")

        if not hotkey_map:
            logger.warning("[HotkeyManager] No hotkeys to register!")
            self.listener = None
            return

        try:
            logger.info(f"[HotkeyManager] Starting listener with {len(hotkey_map)} hotkeys...")
            self.listener = keyboard.GlobalHotKeys(hotkey_map)
            self.listener.start()
            logger.info("[HotkeyManager] ✓ Hotkey listener started successfully")
        except Exception as e:
            logger.error(f"[HotkeyManager] ✗ Failed to start GlobalHotKeys listener: {e}", exc_info=True)
            if platform.system() == "Linux":
                logger.error("[HotkeyManager] On Linux, you may need to install 'python3-xlib' and run as root.")
            elif platform.system() == "Windows":
                logger.error("[HotkeyManager] On Windows, ensure app is running with sufficient privileges.")
            self.listener = None
            return

        self._last_registered_hotkeys = {
            'modes': modes.copy(),
            'models_hotkeys': models_hotkeys.copy()
        }

    def _make_safe_callback(self, func, callback_name):
        """Create a safe callback wrapper that catches exceptions."""
        def safe_wrapper():
            try:
                logger.debug(f"[HotkeyManager] Executing: {callback_name}")
                func()
                logger.debug(f"[HotkeyManager] ✓ Completed: {callback_name}")
            except Exception as e:
                logger.error(f"[HotkeyManager] ✗ Error in {callback_name}: {e}", exc_info=True)
        return safe_wrapper

    def _switch_model(self, model_name):
        """Changes the current model and language via settings_manager."""
        logger.info(f"Switching to model: {model_name}")
        models_dict = self.settings_manager.get('models', {})
        model_lang = None
        for lang, lang_models in models_dict.items():
            for model in lang_models:
                if model.get('name') == model_name:
                    model_lang = model.get('language', lang)
                    break
            if model_lang:
                break

        if model_lang is None:
            logger.error(f"Failed to determine language for model {model_name}")
            return

        self.settings_manager.set('current_model', model_name)
        self.settings_manager.set('language', model_lang)

    def stop(self):
        """Stops the hotkey listener thread."""
        if self.listener and self.listener.is_alive():
            logger.info("Stopping hotkey listener.")
            self.listener.stop()
            self.listener.join()
        self.listener = None

    def __del__(self):
        """Ensure the listener is stopped when the manager is deleted."""
        self.stop()
